int prompt_char(char *strg);
